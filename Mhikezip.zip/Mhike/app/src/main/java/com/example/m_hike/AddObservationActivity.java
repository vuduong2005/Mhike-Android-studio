package com.example.m_hike;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddObservationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int hikeId;
    private int obsIdToEdit = -1;
    private boolean isEditMode = false;

    private EditText etName, etComment;
    private ImageView ivImage;
    private String imageUriString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_observation);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        dbHelper = new DatabaseHelper(this);

        // Get IDs
        hikeId = getIntent().getIntExtra("HIKE_ID", -1);

        // Initialize Views
        etName = findViewById(R.id.etObsName);
        etComment = findViewById(R.id.etObsComment);
        ivImage = findViewById(R.id.ivObsImage);
        Button btnSelectImage = findViewById(R.id.btnObsSelectImage);
        Button btnSave = findViewById(R.id.btnSaveObservation);

        // CHECK FOR EDIT MODE
        if (getIntent().hasExtra("OBS_ID_TO_EDIT")) {
            obsIdToEdit = getIntent().getIntExtra("OBS_ID_TO_EDIT", -1);
            isEditMode = true;
            btnSave.setText("Update Observation");
            loadObservationData(obsIdToEdit);
        }

        btnSelectImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            startActivityForResult(intent, 200);
        });

        btnSave.setOnClickListener(v -> saveObservation());
    }

    private void loadObservationData(int id) {
        Cursor cursor = dbHelper.getObservation(id);
        if (cursor != null && cursor.moveToFirst()) {
            etName.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_NAME)));
            etComment.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_COMMENT)));

            imageUriString = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_IMAGE));
            if (imageUriString != null && !imageUriString.isEmpty()) {
                ivImage.setImageURI(Uri.parse(imageUriString));
            }
            cursor.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 200 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                imageUriString = uri.toString();
                ivImage.setImageURI(uri);
            }
        }
    }

    private void saveObservation() {
        String name = etName.getText().toString().trim();
        String comment = etComment.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Observation Name is required", Toast.LENGTH_SHORT).show();
            return;
        }

        String timeStamp = new SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(new Date());

        if (isEditMode) {
            // UPDATE
            dbHelper.updateObservation(obsIdToEdit, name, timeStamp, comment, imageUriString);
            Toast.makeText(this, "Observation Updated!", Toast.LENGTH_SHORT).show();
        } else {
            // INSERT (New)
            long id = dbHelper.insertObservation(hikeId, name, timeStamp, comment, imageUriString);
            if (id > 0) Toast.makeText(this, "Observation Added!", Toast.LENGTH_SHORT).show();
        }

        finish();
    }
}
package com.example.m_hike;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color; // Needed for Color.RED
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class AddHikeActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etName, etLocation, etLength, etDescription, etTerrain, etDuration;
    private TextView tvDateDisplay, tvLabelName, tvLabelLocation, tvLabelDate, tvLabelParking, tvLabelLength, tvLabelDifficulty;
    private Button btnDate, btnSaveHike, btnSelectImage;
    private ImageView ivHikeImagePreview;
    private Spinner spParking, spDifficulty;
    private String selectedDate = "";
    private String imageUriString = "";

    private int hikeIdToEdit = -1;
    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_hike);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        dbHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etLocation = findViewById(R.id.etLocation);
        etLength = findViewById(R.id.etLength);
        etDescription = findViewById(R.id.etDescription);
        etTerrain = findViewById(R.id.etTerrain);
        etDuration = findViewById(R.id.etDuration);

        tvLabelName = findViewById(R.id.tvLabelName);
        tvLabelLocation = findViewById(R.id.tvLabelLocation);
        tvLabelDate = findViewById(R.id.tvLabelDate);
        tvLabelParking = findViewById(R.id.tvLabelParking);
        tvLabelLength = findViewById(R.id.tvLabelLength);
        tvLabelDifficulty = findViewById(R.id.tvLabelDifficulty);

        ivHikeImagePreview = findViewById(R.id.ivHikeImagePreview);
        btnSelectImage = findViewById(R.id.btnSelectImage);
        btnDate = findViewById(R.id.btnDate);
        btnSaveHike = findViewById(R.id.btnSaveHike);
        tvDateDisplay = findViewById(R.id.tvDateDisplay);
        spParking = findViewById(R.id.spParking);
        spDifficulty = findViewById(R.id.spDifficulty);

        setupSpinners();

        // Check for Edit Mode
        if (getIntent().hasExtra("HIKE_ID_TO_EDIT")) {
            hikeIdToEdit = getIntent().getIntExtra("HIKE_ID_TO_EDIT", -1);
            isEditMode = true;
            btnSaveHike.setText("UPDATE HIKE");
            loadHikeDataForEditing(hikeIdToEdit);
        }

        btnDate.setOnClickListener(v -> showDatePicker());
        btnSaveHike.setOnClickListener(v -> validateAndConfirmHike());

        btnSelectImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            startActivityForResult(intent, 100);
        });
    }

    private void loadHikeDataForEditing(int id) {
        Cursor cursor = dbHelper.getHike(id);
        if (cursor != null && cursor.moveToFirst()) {
            etName.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_NAME)));
            etLocation.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_LOCATION)));
            etLength.setText(String.valueOf(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_LENGTH))));
            etDescription.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DESCRIPTION)));
            etTerrain.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_TERRAIN)));
            etDuration.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DURATION)));

            selectedDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DATE));
            tvDateDisplay.setText("Selected Date: " + selectedDate);

            imageUriString = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_IMAGE));
            if (imageUriString != null && !imageUriString.isEmpty()) {
                ivHikeImagePreview.setImageURI(Uri.parse(imageUriString));
            }

            String parkingVal = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_PARKING));
            if (parkingVal.equals("No")) spParking.setSelection(1);

            String diffVal = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DIFFICULTY));
            ArrayAdapter<CharSequence> adapter = (ArrayAdapter<CharSequence>) spDifficulty.getAdapter();
            spDifficulty.setSelection(adapter.getPosition(diffVal));

            cursor.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                getContentResolver().takePersistableUriPermission(imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                imageUriString = imageUri.toString();
                ivHikeImagePreview.setImageURI(imageUri);
            }
        }
    }

    private void setupSpinners() {
        ArrayAdapter<CharSequence> parkingAdapter = ArrayAdapter.createFromResource(this,
                R.array.parking_options, android.R.layout.simple_spinner_item);
        parkingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spParking.setAdapter(parkingAdapter);

        ArrayAdapter<CharSequence> difficultyAdapter = ArrayAdapter.createFromResource(this,
                R.array.difficulty_levels, android.R.layout.simple_spinner_item);
        difficultyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDifficulty.setAdapter(difficultyAdapter);
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    selectedDate = String.format(Locale.getDefault(), "%02d/%02d/%d", selectedDay, selectedMonth + 1, selectedYear);
                    tvDateDisplay.setText("Selected Date: " + selectedDate);
                }, year, month, day);
        datePickerDialog.show();
    }

    private void resetLabels() {
        int defaultColor = Color.BLACK;
        tvLabelName.setTextColor(defaultColor);
        tvLabelLocation.setTextColor(defaultColor);
        tvLabelDate.setTextColor(defaultColor);
        tvLabelParking.setTextColor(defaultColor);
        tvLabelLength.setTextColor(defaultColor);
        tvLabelDifficulty.setTextColor(defaultColor);
    }

    //  Validation Logic
    private void validateAndConfirmHike() {
        resetLabels(); // Clear previous errors

        String name = etName.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        String lengthStr = etLength.getText().toString().trim();
        String parking = spParking.getSelectedItem().toString();
        String difficulty = spDifficulty.getSelectedItem().toString();

        // Check Name
        if (name.isEmpty()) {
            tvLabelName.setTextColor(Color.RED);
            etName.requestFocus();
            Toast.makeText(this, "Please enter the Name.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check Location
        if (location.isEmpty()) {
            tvLabelLocation.setTextColor(Color.RED);
            etLocation.requestFocus();
            Toast.makeText(this, "Please enter the Location.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check Date
        if (selectedDate.isEmpty()) {
            tvLabelDate.setTextColor(Color.RED);
            btnDate.performClick(); // Open the picker automatically
            Toast.makeText(this, "Please select a Date.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check Length
        if (lengthStr.isEmpty()) {
            tvLabelLength.setTextColor(Color.RED);
            etLength.requestFocus();
            Toast.makeText(this, "Please enter the Length.", Toast.LENGTH_SHORT).show();
            return;
        }

        double length;
        try {
            length = Double.parseDouble(lengthStr);
        } catch (NumberFormatException e) {
            tvLabelLength.setTextColor(Color.RED);
            etLength.requestFocus();
            Toast.makeText(this, "Length must be a valid number.", Toast.LENGTH_SHORT).show();
            return;
        }

        String confirmationMessage = "Please confirm the details:\n\n" +
                "Name: " + name + "\n" +
                "Location: " + location + "\n" +
                "Date: " + selectedDate + "\n" +
                "Parking: " + parking + "\n" +
                "Length: " + length + " km\n" +
                "Difficulty: " + difficulty + "\n" +
                "Description: " + etDescription.getText().toString().trim() + "\n" +
                "Terrain: " + etTerrain.getText().toString().trim() + "\n" +
                "Duration: " + etDuration.getText().toString().trim();

        new AlertDialog.Builder(this)
                .setTitle(isEditMode ? "Update Hike Details" : "Confirm Hike Details")
                .setMessage(confirmationMessage)
                .setPositiveButton(isEditMode ? "Confirm Update" : "Confirm and Save", (dialog, which) -> saveHikeToDatabase(length))
                .setNegativeButton("Go Back and Edit", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void saveHikeToDatabase(double length) {
        String name = etName.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String terrain = etTerrain.getText().toString().trim();
        String duration = etDuration.getText().toString().trim();
        String parking = spParking.getSelectedItem().toString();
        String difficulty = spDifficulty.getSelectedItem().toString();

        if (isEditMode) {
            dbHelper.updateHike(hikeIdToEdit, name, imageUriString, location, selectedDate, parking, length, difficulty, description, terrain, duration);
            Toast.makeText(this, "Hike updated successfully!", Toast.LENGTH_LONG).show();
        } else {
            long id = dbHelper.insertHike(name, imageUriString, location, selectedDate, parking, length, difficulty, description, terrain, duration);
            if (id > 0) Toast.makeText(this, "Hike saved successfully!", Toast.LENGTH_LONG).show();
        }

        finish();
    }
}
package com.example.m_hike;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HikeAdapter extends RecyclerView.Adapter<HikeAdapter.HikeViewHolder> {

    private final Context context;
    private final List<Hike> hikeList;
    private final DatabaseHelper dbHelper;

    public HikeAdapter(Context context, List<Hike> hikeList) {
        this.context = context;
        this.hikeList = hikeList;
        this.dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public HikeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_hike, parent, false);
        return new HikeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HikeViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Hike currentHike = hikeList.get(position);

        holder.tvName.setText(currentHike.getName());
        holder.tvDate.setText(currentHike.getDate());
        holder.tvLocation.setText(currentHike.getLocation());

        //  CLICKING THE ROW OPENS DETAIL VIEW
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, HikeDetailActivity.class);
            intent.putExtra("HIKE_ID", currentHike.getId());
            context.startActivity(intent);
        });

        // EDIT BUTTON CLICK
        holder.btnEdit.setOnClickListener(v -> {
            // We reuse AddHikeActivity but pass the ID so it knows to "Update" instead of "Save"
            Intent intent = new Intent(context, AddHikeActivity.class);
            intent.putExtra("HIKE_ID_TO_EDIT", currentHike.getId());
            context.startActivity(intent);
        });

        // DELETE BUTTON CLICK
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Hike")
                    .setMessage("Are you sure you want to delete '" + currentHike.getName() + "'?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // 1. Delete from Database
                        dbHelper.deleteHike(currentHike.getId());
                        // 2. Remove from List
                        hikeList.remove(position);
                        // 3. Notify Adapter to refresh UI
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, hikeList.size());
                        Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return hikeList.size();
    }

    public static class HikeViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDate, tvLocation;
        ImageButton btnEdit, btnDelete;

        public HikeViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvHikeName);
            tvDate = itemView.findViewById(R.id.tvHikeDate);
            tvLocation = itemView.findViewById(R.id.tvHikeLocation);
            btnEdit = itemView.findViewById(R.id.btnEditHike);
            btnDelete = itemView.findViewById(R.id.btnDeleteHike);
        }
    }
}
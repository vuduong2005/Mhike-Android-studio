package com.example.m_hike;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView; // Import SearchView
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HikeListActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private HikeAdapter adapter;
    private TextView tvNoHikes;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hike_list);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerViewHikes);
        tvNoHikes = findViewById(R.id.tvNoHikes);
        searchView = findViewById(R.id.searchViewHike);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load all data initially
        loadHikeData("");

        // Set up the Search Listener
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Called when user presses "Enter" on keyboard
                loadHikeData(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Called every time the user types a letter (Real-time search)
                loadHikeData(newText);
                return false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the list (clear search) when coming back
        searchView.setQuery("", false);
        searchView.clearFocus();
        loadHikeData("");
    }

    //  UPDATED: Now accepts a 'keyword' to filter results
    private void loadHikeData(String keyword) {
        Cursor cursor;

        if (keyword.isEmpty()) {
            cursor = dbHelper.getAllHikes(); // No search text? Get everything.
        } else {
            cursor = dbHelper.searchHikes(keyword); // Search text? Filter it.
        }

        if (cursor == null || cursor.getCount() == 0) {
            tvNoHikes.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
            return;
        }

        tvNoHikes.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        List<Hike> hikeList = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Hike hike = new Hike();
                hike.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_ID)));
                hike.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_NAME)));
                hike.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_LOCATION)));
                hike.setDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DATE)));
                hikeList.add(hike);
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new HikeAdapter(this, hikeList);
        recyclerView.setAdapter(adapter);
    }

    // Menu Code (Same as before)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.hike_list_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_add_hike) {
            startActivity(new Intent(HikeListActivity.this, AddHikeActivity.class));
            return true;
        }
        if (id == R.id.action_delete_all) {
            showDeleteAllConfirmation();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showDeleteAllConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Database")
                .setMessage("Are you sure you want to delete ALL hike and observation data? This cannot be undone.")
                .setPositiveButton("Yes, Delete All", (dialog, which) -> {
                    dbHelper.deleteAllData();
                    loadHikeData(""); // Refresh with empty list
                    Toast.makeText(this, "Database reset successfully.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
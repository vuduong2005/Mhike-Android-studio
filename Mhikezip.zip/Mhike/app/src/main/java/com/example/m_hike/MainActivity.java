package com.example.m_hike; // Ensure this matches your project's package name

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Assumes your menu layout is named activity_main.xml
        setContentView(R.layout.activity_main);

        // 1. Initialize the "Add Hike" button (Feature A)
        Button btnAddHike = findViewById(R.id.btnAddHike);

        // 2. Initialize the "View Hikes" button (Feature B)
        Button btnViewHikes = findViewById(R.id.btnViewHikes);

        //  Feature A: Add Hike Listener
        btnAddHike.setOnClickListener(v -> {
            // FIX: Corrected typo from AddHikeActuivity to AddHikeActivity
            Intent intent = new Intent(MainActivity.this, AddHikeActivity.class);
            startActivity(intent);
        });

        // Feature B: View Hikes Listener
        btnViewHikes.setOnClickListener(v -> {
            // Starts the activity that lists all saved hikes
            Intent intent = new Intent(MainActivity.this, HikeListActivity.class);
            startActivity(intent);
        });
    }
}
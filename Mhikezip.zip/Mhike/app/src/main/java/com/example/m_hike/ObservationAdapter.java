package com.example.m_hike;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ObservationAdapter extends RecyclerView.Adapter<ObservationAdapter.ObsViewHolder> {

    private final Context context;
    private final List<Observation> obsList;
    private final DatabaseHelper dbHelper; // Need DB Helper for delete

    public ObservationAdapter(Context context, List<Observation> obsList) {
        this.context = context;
        this.obsList = obsList;
        this.dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ObsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_observation, parent, false);
        return new ObsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ObsViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Observation obs = obsList.get(position);
        holder.tvName.setText(obs.getName());
        holder.tvTime.setText(obs.getTime());
        holder.tvComment.setText(obs.getComment());

        if (obs.getImageUri() != null && !obs.getImageUri().isEmpty()) {
            try {
                holder.imgView.setImageURI(Uri.parse(obs.getImageUri()));
            } catch (Exception e) {
                holder.imgView.setImageResource(android.R.drawable.ic_menu_camera);
            }
        } else {
            holder.imgView.setImageResource(android.R.drawable.ic_menu_camera);
        }

        // --- EDIT BUTTON ---
        holder.btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, AddObservationActivity.class);
            intent.putExtra("OBS_ID_TO_EDIT", obs.getId());
            // We also need the Hike ID to keep the context valid
            // But since we are editing, we mostly need the Obs ID.
            context.startActivity(intent);
        });

        // --- DELETE BUTTON ---
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Observation")
                    .setMessage("Are you sure you want to delete '" + obs.getName() + "'?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        dbHelper.deleteObservation(obs.getId());
                        obsList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, obsList.size());
                        Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return obsList.size();
    }

    public static class ObsViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvTime, tvComment;
        ImageView imgView;
        ImageButton btnEdit, btnDelete;

        public ObsViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvObsName);
            tvTime = itemView.findViewById(R.id.tvObsTime);
            tvComment = itemView.findViewById(R.id.tvObsComment);
            imgView = itemView.findViewById(R.id.imgObservation);
            btnEdit = itemView.findViewById(R.id.btnEditObs);
            btnDelete = itemView.findViewById(R.id.btnDeleteObs);
        }
    }
}
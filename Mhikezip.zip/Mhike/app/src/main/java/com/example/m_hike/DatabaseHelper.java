package com.example.m_hike;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "M_Hike_DB";
    private static final int DATABASE_VERSION = 3;

    // Hike Constants
    public static final String TBL_HIKES = "hikes";
    public static final String COL_H_ID = "hike_id";
    public static final String COL_H_NAME = "name";
    public static final String COL_H_IMAGE = "image_uri";
    public static final String COL_H_LOCATION = "location";
    public static final String COL_H_DATE = "date";
    public static final String COL_H_PARKING = "parking";
    public static final String COL_H_LENGTH = "length";
    public static final String COL_H_DIFFICULTY = "difficulty";
    public static final String COL_H_DESCRIPTION = "description";
    public static final String COL_H_TERRAIN = "terrain";
    public static final String COL_H_DURATION = "duration";

    // Observation Constants
    public static final String TBL_OBSERVATIONS = "observations";
    public static final String COL_O_ID = "observation_id";
    public static final String COL_O_HIKE_ID = "hike_ref_id"; // Foreign Key
    public static final String COL_O_NAME = "observation";
    public static final String COL_O_TIME = "time";
    public static final String COL_O_COMMENT = "comment";
    public static final String COL_O_IMAGE = "image_uri";

    private static final String CREATE_HIKE_TABLE =
            "CREATE TABLE " + TBL_HIKES + " (" +
                    COL_H_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_H_NAME + " TEXT NOT NULL, " +
                    COL_H_IMAGE + " TEXT, " +
                    COL_H_LOCATION + " TEXT NOT NULL, " +
                    COL_H_DATE + " TEXT NOT NULL, " +
                    COL_H_PARKING + " TEXT NOT NULL, " +
                    COL_H_LENGTH + " REAL NOT NULL, " +
                    COL_H_DIFFICULTY + " TEXT NOT NULL, " +
                    COL_H_DESCRIPTION + " TEXT, " +
                    COL_H_TERRAIN + " TEXT, " +
                    COL_H_DURATION + " TEXT);";

    private static final String CREATE_OBSERVATION_TABLE =
            "CREATE TABLE " + TBL_OBSERVATIONS + " (" +
                    COL_O_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_O_HIKE_ID + " INTEGER, " +
                    COL_O_NAME + " TEXT NOT NULL, " +
                    COL_O_TIME + " TEXT NOT NULL, " +
                    COL_O_COMMENT + " TEXT, " +
                    COL_O_IMAGE + " TEXT, " +
                    "FOREIGN KEY(" + COL_O_HIKE_ID + ") REFERENCES " + TBL_HIKES + "(" + COL_H_ID + ") ON DELETE CASCADE);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_HIKE_TABLE);
        db.execSQL(CREATE_OBSERVATION_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TBL_HIKES);
        db.execSQL("DROP TABLE IF EXISTS " + TBL_OBSERVATIONS);
        onCreate(db);
    }

    // --- INSERT HIKE ---
    public long insertHike(String name, String imageUri, String location, String date, String parking, double length, String difficulty, String description, String terrain, String duration) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_H_NAME, name);
        values.put(COL_H_IMAGE, imageUri);
        values.put(COL_H_LOCATION, location);
        values.put(COL_H_DATE, date);
        values.put(COL_H_PARKING, parking);
        values.put(COL_H_LENGTH, length);
        values.put(COL_H_DIFFICULTY, difficulty);
        values.put(COL_H_DESCRIPTION, description);
        values.put(COL_H_TERRAIN, terrain);
        values.put(COL_H_DURATION, duration);
        long id = db.insert(TBL_HIKES, null, values);
        db.close();
        return id;
    }

    // --- INSERT OBSERVATION ---
    public long insertObservation(int hikeId, String name, String time, String comment, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_O_HIKE_ID, hikeId);
        values.put(COL_O_NAME, name);
        values.put(COL_O_TIME, time);
        values.put(COL_O_COMMENT, comment);
        values.put(COL_O_IMAGE, imageUri);
        long id = db.insert(TBL_OBSERVATIONS, null, values);
        db.close();
        return id;
    }

    // GET OBSERVATIONS LIST
    public Cursor getObservations(int hikeId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TBL_OBSERVATIONS, null, COL_O_HIKE_ID + "=?",
                new String[]{String.valueOf(hikeId)}, null, null, COL_O_ID + " DESC");
    }

    // GET ALL HIKES
    public Cursor getAllHikes() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TBL_HIKES, null, null, null, null, null, COL_H_NAME + " ASC");
    }

    // GET SINGLE HIKE
    public Cursor getHike(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TBL_HIKES, null, COL_H_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
    }

    // DELETE ALL DATA
    public void deleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TBL_OBSERVATIONS);
        db.execSQL("DELETE FROM " + TBL_HIKES);
        db.close();
    }

    //UPDATE HIKE
    public void updateHike(int id, String name, String imageUri, String location, String date, String parking, double length, String difficulty, String description, String terrain, String duration) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_H_NAME, name);
        values.put(COL_H_IMAGE, imageUri);
        values.put(COL_H_LOCATION, location);
        values.put(COL_H_DATE, date);
        values.put(COL_H_PARKING, parking);
        values.put(COL_H_LENGTH, length);
        values.put(COL_H_DIFFICULTY, difficulty);
        values.put(COL_H_DESCRIPTION, description);
        values.put(COL_H_TERRAIN, terrain);
        values.put(COL_H_DURATION, duration);

        db.update(TBL_HIKES, values, COL_H_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    //DELETE SINGLE HIKE
    public void deleteHike(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TBL_HIKES, COL_H_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    // GET SINGLE OBSERVATION (For Editing)
    public Cursor getObservation(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TBL_OBSERVATIONS, null, COL_O_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
    }

    //UPDATE OBSERVATION
    public void updateObservation(int id, String name, String time, String comment, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_O_NAME, name);
        values.put(COL_O_TIME, time);
        values.put(COL_O_COMMENT, comment);
        values.put(COL_O_IMAGE, imageUri);

        db.update(TBL_OBSERVATIONS, values, COL_O_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    // DELETE OBSERVATION
    public void deleteObservation(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TBL_OBSERVATIONS, COL_O_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public Cursor searchHikes(String keyword) {
        SQLiteDatabase db = this.getReadableDatabase();
        // SQL Query: SELECT * FROM hikes WHERE name LIKE '%keyword%'
        // The % symbols mean "match anything before or after this text"
        return db.query(TBL_HIKES, null, COL_H_NAME + " LIKE ?",
                new String[]{"%" + keyword + "%"}, null, null, COL_H_NAME + " ASC");
    }

}
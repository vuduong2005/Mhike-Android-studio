package com.example.m_hike;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HikeDetailActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int hikeId;
    private RecyclerView recyclerObs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hike_detail);

        dbHelper = new DatabaseHelper(this);
        hikeId = getIntent().getIntExtra("HIKE_ID", -1);
        recyclerObs = findViewById(R.id.recyclerObservations);
        recyclerObs.setLayoutManager(new LinearLayoutManager(this));

        if (hikeId != -1) {
            loadHikeDetails(hikeId);
            loadObservations();
        } else {
            Toast.makeText(this, "Error loading details", Toast.LENGTH_SHORT).show();
            finish();
        }

        Button btnAddObservation = findViewById(R.id.btnAddObservation);
        btnAddObservation.setOnClickListener(v -> {
            Intent intent = new Intent(HikeDetailActivity.this, AddObservationActivity.class);
            intent.putExtra("HIKE_ID", hikeId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadObservations();
    }

    private void loadObservations() {
        Cursor cursor = dbHelper.getObservations(hikeId);
        List<Observation> list = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                Observation o = new Observation();
                o.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_ID)));
                o.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_NAME)));
                o.setTime(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_TIME)));
                o.setComment(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_COMMENT)));
                o.setImageUri(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_O_IMAGE)));
                list.add(o);
            } while (cursor.moveToNext());
        }
        cursor.close();
        ObservationAdapter adapter = new ObservationAdapter(this, list);
        recyclerObs.setAdapter(adapter);
    }

    private void loadHikeDetails(int id) {
        Cursor cursor = dbHelper.getHike(id);
        if (cursor != null && cursor.moveToFirst()) {
            TextView name = findViewById(R.id.tvDetailName);
            ImageView image = findViewById(R.id.ivDetailImage);
            TextView location = findViewById(R.id.tvDetailLocation);
            TextView date = findViewById(R.id.tvDetailDate);
            TextView parking = findViewById(R.id.tvDetailParking);
            TextView length = findViewById(R.id.tvDetailLength);
            TextView difficulty = findViewById(R.id.tvDetailDifficulty);
            TextView description = findViewById(R.id.tvDetailDescription);

            name.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_NAME)));
            location.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_LOCATION)));
            date.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DATE)));
            parking.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_PARKING)));
            length.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_LENGTH)) + " km");
            difficulty.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DIFFICULTY)));
            description.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_DESCRIPTION)));

            String imageUriString = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_H_IMAGE));
            if (imageUriString != null && !imageUriString.isEmpty()) {
                image.setImageURI(Uri.parse(imageUriString));
            }
            cursor.close();
        }
    }
}